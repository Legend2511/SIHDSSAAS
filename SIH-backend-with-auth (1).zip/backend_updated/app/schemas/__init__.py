# WeatherGPT schemas package
